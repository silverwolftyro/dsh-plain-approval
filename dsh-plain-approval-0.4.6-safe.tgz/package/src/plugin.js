/**
 * 白话审批 —— Host 半边。
 *
 * 职责：
 *  1. 在 `approval/request` 水位线上做**同步**的本地规则判断，把七段结论写回
 *     `req.displayReason['plain-approval']`（绝不 await，绝不拖住审批弹窗）。
 *  2. **长期同意（v0.3）**：命中的「安全」命令直接返回 `allowed-once` 短路瀑布 ——
 *     不弹窗、自动放行，并写审计日志。
 *  3. 记录挂起审批，供客户端在**让位模式**下用浮层展示。
 *  4. 注册 `/api/plain-approval/*`（前缀**不带尾斜杠**，见 server.js）。
 *  5. 记录槽位自适应（让位/接管）的决定。
 *
 * 任何环节失败都只降级，绝不抛错、绝不阻断审批。
 * @module dsh-plain-approval/plugin
 */
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { createStore } from './store.js'
import { createLogger } from './logger.js'
import { createCache } from './cache.js'
import { createTranslator } from './translate.js'
import { createApiHandler, API_PREFIX } from './server.js'
import { createGrants, workspaceScope } from './grants.js'
import { createAudit } from './audit.js'
import { createOllamaGuard } from './ollama-guard.js'
import { detectDevice } from './device.js'
import { extractContext } from './context.js'
import { evaluateLocalHealth } from './local-health.js'
import { analyzeCommand } from './rules.js'
import { normalizeSettings, mergeDeep, DEFAULT_SETTINGS } from './config.js'
import { safeParse, shortHash, oneLine } from './util.js'

export const name = 'plain-approval'
export const PLUGIN_ID = 'dsh-plain-approval'

/** 插件版本（用于确认「跑起来的到底是哪一版」）。 */
export const VERSION = (() => {
  try {
    return createRequire(import.meta.url)('../package.json').version ?? '0.0.0'
  } catch {
    return '0.0.0'
  }
})()

/** 挂起审批最多保留多少条（防止泄漏）。 */
const MAX_PENDING = 20
/** 挂起审批的最长保留时间（毫秒）——兜底，正常靠 next() 结算清理。 */
const PENDING_TTL_MS = 10 * 60 * 1000

export function apply(ctx, rowConfig = {}) {
  const store = createStore({ env: process.env })
  let userSettings = store.readRawSettings()
  let cachedSettings = normalizeSettings(mergeDeep(rowConfig || {}, userSettings || {}))

  function getSettings() {
    return cachedSettings
  }

  function refreshSettings() {
    userSettings = store.readRawSettings()
    cachedSettings = normalizeSettings(mergeDeep(rowConfig || {}, userSettings || {}))
    return cachedSettings
  }

  function saveSettings(patch) {
    const result = store.saveRawSettings(sanitizeSettingsPatch(patch))
    refreshSettings()
    return { settings: cachedSettings, raw: result.settings }
  }

  const logger = createLogger({ store, ctx, getSettings })
  const cache = createCache({ dir: store.dir, driver: cachedSettings.cache.driver })
  const guard = createOllamaGuard({ getSettings, logger, getDevice: () => translator.lastDevice })
  const translator = createTranslator({ getSettings, cache, store, logger, ctx, guard, detectDevice })
  const grants = createGrants({ dir: store.dir, scope: workspaceScope() })
  const audit = createAudit({ dir: store.dir })

  ctx.logger?.info?.(
    '%s v%s: host 已加载，引擎=%s，缓存=%s，槽位策略=%s，工作区=%s，数据目录=%s',
    PLUGIN_ID,
    VERSION,
    cachedSettings.engine,
    cache.driver,
    cachedSettings.ui.slotPolicy,
    grants.scope,
    store.dir,
  )
  logger.info('host.loaded', {
    version: VERSION,
    engine: cachedSettings.engine,
    cache: cache.driver,
    slotPolicy: cachedSettings.ui.slotPolicy,
    workspace: grants.scope,
    grants: grants.size(),
  })

  /* ---------------------------------------------------------------- */
  /* 0. 槽位自适应状态                                                  */
  /* ---------------------------------------------------------------- */

  let slotState = {
    policy: cachedSettings.ui.slotPolicy,
    yielding: null,
    rivals: [],
    decidedAt: null,
    note: '客户端尚未上报槽位决定（页面还没刷新，或客户端未加载）',
  }

  function noteSlotEvent(event, details) {
    if (event === 'slot.decision') {
      const previous = slotState.yielding
      slotState = {
        policy: details.policy ?? cachedSettings.ui.slotPolicy,
        yielding: details.yielding === true,
        rivals: Array.isArray(details.rivals) ? details.rivals.slice(0, 10) : [],
        decidedAt: new Date().toISOString(),
        note: details.yielding === true
          ? '已让位给：' + (details.rivals?.join('、') || '其它占用审批卡槽位的插件')
          : '当前由白话审批接管审批卡',
      }
      if (previous !== slotState.yielding) {
        logger.info(slotState.yielding ? 'slot.yield' : 'slot.takeover', {
          policy: slotState.policy,
          rivals: slotState.rivals.join(','),
        })
      }
    }
    // 客户端把条目结构 dump 上来时记一条，方便排查让位判定
    if (event === 'slot.entries') {
      logger.info('slot.entries', {
        count: details.count,
        items: oneLine(JSON.stringify(details.items ?? []), 900),
      })
    }
    if (event === 'card.no-command') {
      logger.warn('card.no-command', { tool: details.tool, callId: details.callId })
    }
  }

  function getSlotState() {
    return { ...slotState, policy: cachedSettings.ui.slotPolicy }
  }

  /* ---------------------------------------------------------------- */
  /* 1. 挂起审批表                                                     */
  /* ---------------------------------------------------------------- */

  const pending = new Map()

  function prunePending() {
    const now = Date.now()
    for (const [key, entry] of pending) {
      if (now - entry.at > PENDING_TTL_MS) pending.delete(key)
    }
    while (pending.size > MAX_PENDING) {
      const oldest = [...pending.entries()].sort((a, b) => a[1].at - b[1].at)[0]
      if (!oldest) break
      pending.delete(oldest[0])
    }
  }

  function listPending() {
    prunePending()
    return [...pending.values()]
      .sort((a, b) => b.at - a.at)
      .map((entry) => ({
        key: entry.key,
        at: new Date(entry.at).toISOString(),
        toolName: entry.toolName,
        reason: entry.reason,
        hash: entry.hash,
        command: entry.command,
        commandMissing: entry.commandMissing === true,
        quick: entry.quick,
      }))
  }

  /* ---------------------------------------------------------------- */
  /* 2. 审批水位线                                                      */
  /* ---------------------------------------------------------------- */

  /** 连续多少次「本地通道失败」就临时禁用本地（需求 四.2：2 次）。 */
  let localFailStreak = 0

  /**
   * 观察一次翻译结果里的本地通道健康状况。
   * 用户强行在低配机器上开本地时，连续 2 次因内存/超时失败就自动切回 API 30 分钟。
   */
  function observeLocalHealth(result) {
    try {
      const s = getSettings()
      const next = evaluateLocalHealth({ streak: localFailStreak }, result, {
        allowUnusableLocal: s.device.allowUnusableLocal === true,
      })
      if (!next) return
      localFailStreak = next.streak
      if (next.disableUntil > 0) {
        saveSettings({
          device: { localDisabledUntil: next.disableUntil, localDisabledReason: next.reason },
        })
        logger.warn('device.local-disabled', {
          until: new Date(next.disableUntil).toISOString(),
          reason: next.reason,
        })
      } else if (next.streak > 0) {
        logger.warn('ollama.fail-streak', { streak: next.streak })
      }
    } catch (error) {
      logger.warn('ollama.health-observe-failed', { message: oneLine(error?.message, 160) })
    }
  }

  function commandFromSession(agent, callId) {    try {
      const session = agent?.session
      if (!session || callId === undefined || callId === null) return undefined
      const end = typeof session.seq === 'number' ? session.seq : 0
      for (let seq = end - 1; seq >= 0; seq -= 1) {
        const event = session.eventAt(seq)
        if (!event) continue
        if (event.type !== 'tool/call') continue
        if (String(event.data?.callId) !== String(callId)) continue
        return extractCommand(event.data?.arguments)
      }
    } catch {
      return undefined
    }
    return undefined
  }

  function listener(request, next) {
    let settle = null
    try {
      if (request && typeof request === 'object' && !Object.isFrozen(request)) {
        const settings = getSettings()
        const fromSession = commandFromSession(request.agent, request.callId)
        const commandMissing = fromSession === undefined || fromSession === ''
        const toolName = request.toolName
        // 需求（稳定性）：取不到命令原文也要给卡片一个可渲染的结果，绝不空白。
        const rawCommand = commandMissing ? '' : fromSession
        const truncated = rawCommand.length > 4000 ? rawCommand.slice(0, 4000) : rawCommand

        const rules = analyzeCommand(truncated, { blacklist: settings.blacklist, toolName })

        const quick = translator.ruleOnly({
          command: truncated,
          toolName,
          reason: request.reason,
          callId: request.callId,
        })
        quick.commandMissing = commandMissing
        if (commandMissing) {
          quick.headline = '未能从会话里取到命令原文；卡片会用客户端读到的命令继续翻译'
          quick.sections.what = `准备执行 ${toolZhSafe(toolName)}（原文未能取到）`
        }

        // 会话上下文（任务四）：同步抽取，随 displayReason 一起下发
        const context = commandMissing ? null : extractContext(request.agent, request.callId)
        quick.contextInfo = context ? { available: context.available === true, step: context.step ?? null } : { available: false }

        const display = request.displayReason && typeof request.displayReason === 'object' && !Array.isArray(request.displayReason)
          ? request.displayReason
          : {}
        display['plain-approval'] = quick
        // 卡片内摘要（v0.4.3）：**默认关闭**。
        // 原生卡片（dsh-reject-message 的 `.drm-headline`）会把 displayReason 的本地化字符串
        // 直接当标题渲染；用户嫌那行摘要多余。关闭时**完全不碰**本地化文本，
        // 让卡片回落到它自己的原生原因，翻译只从浮窗进（入口是卡片上的「白话翻译」按钮）。
        if (getSettings().ui.showInlineSummary === true) {
          display.zh = `白话翻译：${oneLine(quick.sections.what, 30)}（风险：${quick.sections.risk}）· 点卡片上的「白话翻译」看详情`
          display.en = `Plain: ${oneLine(quick.sections.what, 40)} (risk: ${quick.sections.risk}) · click "Translate" on the card for details`
        }
        const hadDisplay = request.displayReason !== undefined
        if (hadDisplay || getSettings().ui.showInlineSummary === true) {
          request.displayReason = display
        }

        if (!commandMissing) {
          // ---- 长期同意（v0.3）：命中且规则判「安全」→ 短路瀑布，不弹窗 ----
          const grant = grants.match(truncated)
          if (grant && grant.risk === '安全' && rules.risk === '安全') {
            const used = grants.markUsed(grant.id)
            audit.record({
              event: 'auto-allow',
              hash: shortHash(truncated),
              ruleId: grant.id,
              workspace: grant.scope,
              toolName,
              risk: rules.risk,
              engine: 'grant',
              sections: quick.sections,
            })
            audit.trim()
            logger.info('grant.auto-allow', {
              hash: shortHash(truncated),
              ruleId: grant.id,
              workspace: grant.scope,
              uses: used?.uses ?? null,
              tool: toolName,
            })
            return 'allowed-once'
          }

          const key = shortHash(truncated) + ':' + String(request.callId ?? '')
          pending.set(key, {
            key,
            at: Date.now(),
            toolName,
            reason: typeof request.reason === 'string' ? oneLine(request.reason, 200) : undefined,
            hash: shortHash(truncated),
            command: truncated,
            commandMissing: false,
            context,
            quick,
          })
          prunePending()
          settle = () => pending.delete(key)

          // 需求 35：翻译排队执行；这里只排队，不等结果，不阻塞审批。
          // 顺带观察通道 A 的失败：连续 2 次因 OOM/超时失败就临时禁用本地通道 30 分钟。
          void translator
            .translate({
              command: truncated,
              toolName,
              reason: request.reason,
              callId: request.callId,
              confirmPaid: true,
              context,
            })
            .then((result) => {
              observeLocalHealth(result)
            })
            .catch(() => undefined)
          logger.info('approval.seen', {
            hash: shortHash(truncated),
            risk: rules.risk,
            tool: toolName,
            localOnly: rules.localOnly === true,
            tempCleanup: rules.tempCleanup === true,
            commandMissing: false,
            context: context?.available === true ? 'yes' : 'no',
            yielding: slotState.yielding === true,
          })
        } else {
          logger.warn('approval.no-command', { tool: toolName, callId: String(request.callId ?? '') })
        }
      }
    } catch (error) {
      logger.warn('approval.listener-failed', { message: oneLine(error?.message, 200) })
    }

    // 关键：立刻把控制权交回去（同步），绝不 await 翻译。
    let outcome
    try {
      outcome = next()
    } catch (error) {
      settle?.()
      throw error
    }
    if (settle) Promise.resolve(outcome).then(settle, settle)
    return outcome
  }

  try {
    const disposer = ctx.on('approval/request', listener, { prepend: true })
    ctx.effect(() => disposer, PLUGIN_ID + ': approval/request listener')
  } catch (error) {
    try {
      const disposer = ctx.on('approval/request', listener)
      ctx.effect(() => disposer, PLUGIN_ID + ': approval/request listener (fallback)')
    } catch (inner) {
      logger.warn('approval.listen-failed', { message: oneLine(inner?.message, 200) })
    }
  }

  /* ---------------------------------------------------------------- */
  /* 3. HTTP 接口                                                       */
  /* ---------------------------------------------------------------- */

  try {
    ctx.inject(['webServer'], (scope) => {
      const handler = createApiHandler({
        ctx,
        version: VERSION,
        getSettings,
        saveSettings,
        translator,
        logger,
        store,
        cache,
        grants,
        audit,
        guard,
        detectDevice,
        assetsDir: fileURLToPath(new URL('../assets/', import.meta.url)),
        getRowConfig: () => rowConfig,
        listPending,
        getSlotState,
        noteSlotEvent,
      })
      scope.effect(
        () =>
          scope.webServer.register({
            kind: 'prefix',
            // ⚠️ 不要加尾斜杠：webserver.match() 用 `startsWith(prefix + '/')` 判定，
            // 带尾斜杠会让所有子路径都匹配不上，表现为浏览器里 HTTP 404。
            path: API_PREFIX,
            handler: (req, res) => {
              Promise.resolve(handler(req, res)).catch((error) => {
                try {
                  res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
                  res.end(JSON.stringify({ ok: false, error: oneLine(error?.message, 200) }))
                } catch {
                  /* 忽略 */
                }
              })
            },
          }),
        PLUGIN_ID + ': http api',
      )
      logger.info('http.registered', { prefix: API_PREFIX })
    })
  } catch (error) {
    logger.warn('http.register-failed', { message: oneLine(error?.message, 200) })
  }

  ctx.effect(() => () => {
    try {
      cache.close()
    } catch {
      /* 忽略 */
    }
  }, PLUGIN_ID + ': teardown')
}

function toolZhSafe(toolName) {
  const map = { pwsh: 'PowerShell 命令', bash: '命令行命令', write: '写文件', edit: '改文件', read: '读文件' }
  const key = String(toolName ?? '').trim()
  return map[key] || key || '工具'
}

/**
 * 长期同意授权**不能**通过配置文件批量导入。
 * 这里把所有可能被用来夹带授权表的键全部剔除，只允许逐条手动授权。
 * @param {object} patch
 * @returns {object} 过滤后的设置
 */
export function sanitizeSettingsPatch(patch) {
  const clean = { ...(patch || {}) }
  for (const key of ['grants', 'grantList', 'longTermApprovals', 'alwaysAllow', 'allowList', 'whitelist']) {
    delete clean[key]
  }
  return clean
}

/** tool/call 事件的 arguments 可能是字符串，也可能是对象。 */
export function extractCommand(argumentsRaw) {
  if (typeof argumentsRaw === 'string') {
    const parsed = safeParse(argumentsRaw)
    if (parsed && typeof parsed === 'object') {
      if (typeof parsed.command === 'string') return parsed.command
      if (typeof parsed.file_path === 'string') return `写入/修改文件：${parsed.file_path}`
      if (typeof parsed.path === 'string') return `读写路径：${parsed.path}`
      return JSON.stringify(parsed)
    }
    return argumentsRaw
  }
  if (argumentsRaw && typeof argumentsRaw === 'object') {
    if (typeof argumentsRaw.command === 'string') return argumentsRaw.command
    if (typeof argumentsRaw.file_path === 'string') return `写入/修改文件：${argumentsRaw.file_path}`
    if (typeof argumentsRaw.path === 'string') return `读写路径：${argumentsRaw.path}`
    return JSON.stringify(argumentsRaw)
  }
  return undefined
}

export { DEFAULT_SETTINGS, normalizeSettings, createStore, createCache, createTranslator, createLogger, createApiHandler }
