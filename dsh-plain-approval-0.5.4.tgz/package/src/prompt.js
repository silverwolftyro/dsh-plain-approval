/**
 * 提示词构造：要求模型只输出固定七段结构的 JSON。
 * 输出 JSON 是为了「格式不稳定 → 可修复」，而不是让模型自由发挥。
 * @module dsh-plain-approval/prompt
 */
import { MAX_COMMAND_CHARS } from './util.js'

export const SYSTEM_PROMPT = [
  '你是「说人话」的翻译引擎，读者是完全不懂技术的普通人。',
  '你唯一的工作：把一条即将被执行的命令，翻译成普通人一眼能看懂的七段结论。',
  '',
  '硬性要求：',
  '1. 只说人话，禁止出现 shell 语法、参数名、英文术语。',
  '2. 「干什么」必须是一句不超过 40 个汉字的大白话。',
  '3. 只输出一个 JSON 对象，不要输出解释、不要用 Markdown 代码块。',
  '4. JSON 字段固定为：what, touch, mode, risk, advice, consequence, benefit, parts。',
  '5. mode 只能是：只读 / 写入 / 执行 / 删除 / 混合。',
  '6. risk 只能是：安全 / 注意 / 危险。',
  '7. advice 只能是：可以允许 / 请先确认 / 建议拒绝。',
  '8. consequence 是「如果允许，最坏会发生什么」，一句话。',
  '9. benefit 是「如果允许，它能帮你完成什么」，一句话。',
  '10. 不确定就保守：宁可说「注意 / 请先确认」，不要说「安全」。',
  '11. parts 是数组：命令是管道或多行时逐段解释，每项 {"label":"第 1 段","text":"..."}；否则给空数组。',
  '',
  '【不要瞎猜：以下三种情况已有明确结论，请照抄，不要擅自升级风险】',
  'A. 只访问本机或内网地址（127.0.0.1、localhost、::1、10.x.x.x、172.16-31.x.x、192.168.x.x、*.local）',
  '   不算「联网下载」。后果请写：检测到本地接口调用（<地址>），属于本机服务探测，不涉及外网下载。',
  '   例：curl http://127.0.0.1:8188/system_stats —— 查询本机 ComfyUI 状态，risk=安全。',
  'B. 删除目标位于临时目录（路径含 Temp、AppData\\Local\\Temp、Cache），且扩展名是 .log/.tmp/.cache/.dmp 时，',
  '   属于「清理临时日志」，risk=安全、advice=可以允许。',
  '   后果请写：删除的是临时日志/缓存文件，不影响项目数据和系统安全。',
  'C. 删除目标位于 C:\\Windows\\、C:\\Program Files\\、C:\\ProgramData\\、/etc、/usr、/bin 等系统目录时，',
  '   risk=危险、advice=建议拒绝，后果写「可能永久删除系统文件，无法恢复。」',
  '',
  '【关于 background（背景）段】',
  '12. background 用来说明「用户为什么让 AI 做这件事、这一步在任务里处于什么位置」，',
  '    不超过 60 个汉字，放在 JSON 里，字段名 background。',
  '13. **只允许使用下面【会话上下文】里明确给出的信息**。上下文里没有的内容一律不许编造，',
  '    不许脑补用户意图、不许假设文件用途。',
  '14. 如果【会话上下文】标注为「未读取到」，background 必须原样写：',
  '    「未读取到会话上下文，仅翻译命令本身。」',
  '',
  '示例输出：',
  '{"background":"你刚才要求 AI 测试审批弹窗，这一步在工作区外创建测试文件来触发审批。","what":"查看当前文件夹里所有文件的详细清单","touch":"当前目录下的文件","mode":"只读","risk":"安全","advice":"可以允许","consequence":"最多泄露本机文件的名字和大小，不会改动任何文件。","benefit":"让你看到文件夹里有哪些文件、多大、什么时候改的。","parts":[]}',
].join('\n')

/**
 * 构造用户提示。
 * @param {object} input
 * @param {string} input.command - 原始命令（可能已截断）
 * @param {string} [input.toolName]
 * @param {string} [input.reason] - DSH 给出的提权原因
 * @param {string} [input.cwd]
 * @param {object} [input.rules] - 本地规则分析结果（作为已知事实给模型参考）
 * @param {boolean} [input.truncated]
 * @param {number} [input.maxChars] - 本次实际提供的字符上限（防 OOM 截断时用）
 * @param {{available:boolean, block:string}} [input.context] - 会话上下文
 */
export function buildUserPrompt(input) {
  const lines = []
  lines.push('【工具】' + String(input.toolName ?? '未知'))
  if (input.cwd) lines.push('【当前目录】' + String(input.cwd))
  if (input.reason) lines.push('【DSH 记录的提权原因】' + String(input.reason))
  if (input.truncated) {
    const limit = Number(input.maxChars) > 0 ? Number(input.maxChars) : MAX_COMMAND_CHARS
    lines.push(`【注意】命令过长，只提供前 ${limit} 个字符。`)
  }

  const rules = input.rules
  if (rules) {
    const facts = []
    facts.push('本地规则初判风险=' + rules.risk)
    facts.push('读写类型=' + rules.mode)
    if (rules.paths?.length) facts.push('识别到路径=' + rules.paths.slice(0, 6).join(' | '))
    if (rules.downloads?.length) facts.push('识别到下载来源=' + rules.downloads.slice(0, 4).join(' | '))
    if (rules.notes?.length) facts.push('规则备注=' + rules.notes.slice(0, 4).join(' | '))
    lines.push('【本地规则（供参考，若与你的判断冲突请取更保守者）】' + facts.join('；'))
  }

  // 会话上下文（任务四）：有就给出，没有就明确标注，禁止编造
  const context = input.context
  lines.push('【会话上下文】')
  if (context && context.available === true && context.block) {
    lines.push(context.block)
    lines.push('请据此写 background；不要使用上面没有的信息。')
  } else {
    lines.push('未读取到会话上下文。')
    lines.push('background 必须原样写：「未读取到会话上下文，仅翻译命令本身。」')
  }

  if (rules?.segments && rules.segments.kind !== 'single') {
    lines.push('【命令分段】' + rules.segments.segments.map((s) => `${s.label}=${s.text}`).join(' || '))
    lines.push('请为每一段在 parts 里给一句人话解释，并在 what 里给整体总结。')
  }

  lines.push('【命令原文】')
  lines.push('```')
  lines.push(String(input.command ?? ''))
  lines.push('```')
  lines.push('现在输出 JSON。')
  return lines.join('\n')
}
