/**
 * 会话上下文提取（v0.4 任务四之二）。
 *
 * 目标：让翻译知道「用户刚才让 AI 干什么、AI 打算怎么干、这一步在任务链的哪个位置」，
 * 而不是孤立地解释一条命令。
 *
 * 来源优先级（需求指定）：
 *   1. 审批事件附带的 agent/session（最准，有完整事件流）
 *   2. 当前会话最近的消息
 *   3. 兜底：只翻译命令本身，并明确标注「未读取到会话上下文」
 *
 * 隐私：这里只读会话里**已经存在**的文本，不外发任何 DSH 内部数据；
 * 送进模型的上下文会被截断，且只在翻译时使用。
 * @module dsh-plain-approval/context
 */
import { oneLine } from './util.js'

/** 每条上下文最多保留多少字。 */
const USER_CHARS = 120
const ASSISTANT_CHARS = 200
/** 送进提示词的上下文总长度上限。 */
const TOTAL_CHARS = 900

export const NO_CONTEXT_NOTE = '未读取到会话上下文，仅翻译命令本身。'

/** 从消息内容块里抽纯文本。 */
function textOf(message) {
  try {
    const content = message?.content
    if (typeof content === 'string') return content
    if (!Array.isArray(content)) return ''
    return content
      .filter((b) => b && (b.type === 'text' || typeof b.text === 'string'))
      .map((b) => String(b.text ?? ''))
      .join(' ')
  } catch {
    return ''
  }
}

/**
 * 从 agent.session 的事件流里提取上下文。
 * @param {object} agent
 * @param {string} [callId] - 当前这次工具调用，用于定位「这一步」
 * @param {{ maxUser?: number, maxAssistant?: number }} [options]
 * @returns {{
 *   available: boolean, source: 'session'|'none', lines: string[],
 *   step: { index: number, total: number } | null,
 *   note: string, chars: number
 * }}
 */
export function extractContext(agent, callId, options = {}) {
  const maxUser = Number(options.maxUser ?? 3)
  const maxAssistant = Number(options.maxAssistant ?? 2)
  const empty = { available: false, source: 'none', lines: [], step: null, note: NO_CONTEXT_NOTE, chars: 0 }

  const session = agent?.session
  if (!session || typeof session.eventAt !== 'function') return empty
  const end = typeof session.seq === 'number' ? session.seq : 0
  if (end <= 0) return empty

  try {
    const users = []
    const assistants = []
    let turnStart = -1
    let callIndex = -1
    let toolCallsInTurn = 0

    // 第一遍：从后往前找当前 turn 的起点，并统计本回合的工具调用位置
    for (let seq = end - 1; seq >= 0; seq -= 1) {
      const event = session.eventAt(seq)
      if (!event) continue
      if (event.type === 'turn/start') {
        turnStart = seq
        break
      }
    }

    // 第二遍：按顺序读当前回合内的事件（拿 AI 的说明与步骤位置）
    const from = turnStart >= 0 ? turnStart : 0
    for (let seq = from; seq < end; seq += 1) {
      const event = session.eventAt(seq)
      if (!event) continue
      if (event.type === 'tool/call') {
        if (callId !== undefined && String(event.data?.callId) === String(callId)) callIndex = toolCallsInTurn
        toolCallsInTurn += 1
      }
      if (event.type === 'assistant/message') {
        const text = oneLine(textOf(event.data?.message), ASSISTANT_CHARS)
        if (text) assistants.push(text)
      }
    }

    // 第三遍：全会话里最近的 N 条用户消息（用户指令常常在 turn/start 之前）
    for (let seq = end - 1; seq >= 0 && users.length < maxUser; seq -= 1) {
      const event = session.eventAt(seq)
      if (!event || event.type !== 'user/message') continue
      const text = oneLine(textOf(event.data?.message), USER_CHARS)
      if (text) users.unshift(text)
    }

    const lines = []
    if (users.length > 0) lines.push('用户最近的指令：' + users.map((u, i) => `(${i + 1}) ${u}`).join(' '))
    const tailAssistants = assistants.slice(-maxAssistant)
    if (tailAssistants.length > 0) lines.push('AI 在发起这次审批前说过：' + tailAssistants.map((a) => `「${a}」`).join(' '))

    let step = null
    if (callIndex >= 0) {
      step = { index: callIndex + 1, total: toolCallsInTurn }
      lines.push(`这是本回合的第 ${callIndex + 1} 次工具调用（本回合共 ${toolCallsInTurn} 次）。`)
    }

    if (lines.length === 0) return empty
    let joined = lines.join('\n')
    if (joined.length > TOTAL_CHARS) joined = joined.slice(0, TOTAL_CHARS)
    return { available: true, source: 'session', lines: joined.split('\n'), step, note: '', chars: joined.length }
  } catch {
    return empty
  }
}

/** 给提示词用的上下文块（模型不得编造，只能基于这里的内容写「背景」）。 */
export function contextForPrompt(context) {
  if (!context || context.available !== true || context.chars === 0) {
    return { available: false, block: '（未读取到会话上下文）' }
  }
  return { available: true, block: context.lines.join('\n') }
}

/** 模型没给出「背景」时的兜底（不编造，只说从上下文能确定的事实）。 */
export function fallbackIntent(context) {
  if (!context || context.available !== true) return NO_CONTEXT_NOTE
  const first = context.lines[0] ?? ''
  const userPart = first.startsWith('用户最近的指令：') ? first.slice('用户最近的指令：'.length) : ''
  const stepPart = context.step ? `这一步是本回合的第 ${context.step.index} 次操作。` : ''
  const head = userPart ? `结合你最近的指令（${oneLine(userPart, 34)}），` : ''
  const text = head + (stepPart || '这是 AI 为完成当前任务发起的一次操作。')
  return oneLine(text, 60)
}

/** @deprecated 旧名保留一个别名，避免外部引用断裂。 */
export const fallbackBackground = fallbackIntent
